#!/usr/bin/perl

if( $#ARGV == -1 ){
    printf "./all-electrode.pl  <filename(-*.eeg_emg)> <eeg_start> <eeg_end> <time>\n";
    printf "\n";
    exit;
    }


$FILE = $ARGV[0];
$CH1  = $ARGV[1];
$CH2  = $ARGV[2];
$TIME = $ARGV[3];

system "./csd_all-electrode legendre_m.pml legendre_m-1.pml ${FILE} ${CH1} ${TIME}";

for($h = $CH1; $h <= $CH2; $h++)
{
    printf "CH = $h \n";
    system "./FFT_COH2 ${FILE} ${h} ${TIME}";
#    system "mv *ch*linuxcsd* TRIAL/";
}

