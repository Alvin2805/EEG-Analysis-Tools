/*#############################################################################

                           Function for EEG average and standard deviation

                       AVE_EMG(char *new_z,int time,int EEG_CH)

                             No return value
###############################################################################*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include"CSD.h"

AVE_EMG(char *new_z,int time,int EEG_CH)
{
  int MAT, i, j, total_data, start, end;

  double sum, ave, new_data, totalsum, stddev;

  double **data;

  char fin[100];

  FILE *FIN;


  /*################Memory Allocation and Initialization################*/

  data = (double **)calloc(FILESUU*EPOCH*INTERVAL,sizeof(double *));
  if(data == NULL){
      puts("data �Υ��꤬���ݤǤ��ޤ���");
      exit(1);
  }
  for(MAT=0;MAT<(FILESUU*EPOCH*INTERVAL);MAT++){
      *(data + MAT) = (double *)calloc(MATRIX+1,sizeof(double));
      if(*(data + MAT) == NULL){
	  puts("data �Υ��꤬���ݤǤ��ޤ���");
	  exit(1);
      }
  } 
  

/*################ Take absolute value of EMG data and 
                   rewrite data as (|data - average|)---- Ch1################*/

    sprintf(fin,"%s-%d_ch%d.0ch-csd",new_z,time,EMG_CH);


    if((FIN=fopen(fin,"r"))==NULL){
	fprintf(stderr, "I can't find %s. I'm sorry !! \n",fin);
	exit(1);
    }

    total_data = 0;

    while((fscanf(FIN,"%lf",&new_data)) != EOF){
	total_data++;
    }
   
    fclose(FIN);
	  
    if((FIN=fopen(fin,"r"))==NULL){
      fprintf(stderr, "I can't find %s. I'm sorry !! \n",fin);
      exit(1);
    }

    totalsum = 0;

    for(i=0;i<(total_data / INTERVAL);i++){
      
      start = i * INTERVAL;
      end   = (i + 1) * INTERVAL;
      
      for(j=start;j<end;j++){
	fscanf(FIN,"%lf", &data[j][EMG_CH]);
	data[j][EMG_CH] = fabs(data[j][EMG_CH]);
	totalsum+=data[j][EMG_CH];
      }
    }
    
    fclose(FIN);

    printf("sum_all = %lf\t total_data = %d\n", totalsum, total_data);

    ave = totalsum/total_data;
    sum = 0;

    for(i=0;i<total_data;i++){
	data[i][EMG_CH] = sqrt((data[i][EMG_CH] - ave) * (data[i][EMG_CH] - ave));
	sum += data[i][EMG_CH];
    }

    stddev = sum/total_data;

    printf("ave = %lf\tstddev = %lf\n", ave, stddev);

    system("rm *.0ch-csd");
    system("rm *.mul");
     
}











