/*#############################################################################

             Function that remove bad epochs from EMG and EEG and
                      rearrange EEG for z_matrix

                       Remove_bad_epoch(char *new_z,int time)

                             No return value
###############################################################################*/
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include"CSD.h"


Remove_bad_epoch(char *new_z,int time)
{
  int i, j, k, m, ch_number;

  int start, end, MAT; 

  double *eeg_volt;

  double **data;

  double data_emg, data_eeg;
  
  double Max_data;
   
  char fin[100], fout[100], fin_emg[100], fout_emg[100];

  FILE *FIN, *FOUT, *FIN_EMG, *FOUT_EMG;



  /*################Memory Allocation + Initialization############*/

  eeg_volt = (double *)calloc(FILESUU*EPOCH,sizeof(double));
  if(eeg_volt == NULL){
    puts("eeg_volt �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
  }

  data = (double **)calloc(FILESUU*EPOCH*INTERVAL,sizeof(double *));
  if(data == NULL){
    puts("data �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
  }
  for(MAT=0;MAT<(FILESUU*EPOCH*INTERVAL);MAT++){
    *(data + MAT) = (double *)calloc(CHANNELSUU+1,sizeof(double));
    if(*(data + MAT) == NULL){
    puts("data �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
    }
  }


  
  /*################Give Data Memory Allocation################*/

     
  for(ch_number = 0; ch_number < CHANNELSUU; ch_number++){ 
      
    sprintf(fin,"%s_ch%d.ascii",new_z,ch_number);
    if((FIN=fopen(fin,"r"))==NULL){
      perror(fin);
      exit(errno);
    } 
    
    for(j=0;j<(FILESUU * EPOCH * INTERVAL);j++){
      fscanf(FIN,"%lf",&data[j][ch_number]);
    }
      fclose(FIN);
  }

  
 
  /*################New File For EMG After Removed Bad Epochs################*/

   sprintf(fout_emg,"%s-%d_ch%d.0ch-csd",new_z,time,EMG_CH);
   FOUT_EMG=fopen(fout_emg,"w"); 


   /*################Calculate for Max Value( Max > MAXIMUM_VOLT ??)################*/


   k = 0;

  for(ch_number = EEG_START; ch_number <= EEG_END; ch_number++){

    for(i=0;i<(FILESUU * EPOCH);i++){
      
      start = i * INTERVAL;
      end   = (i + 1) * INTERVAL;
           
      for(j=start;j<end;j++){
	Max_data = fabs(data[j][ch_number]);
	if (eeg_volt[i] < Max_data)
	  eeg_volt[i] = Max_data;
      }
   
    }

  }

  for(i=0;i<(FILESUU * EPOCH);i++){
    
    start = i * INTERVAL;
    end   = (i + 1) * INTERVAL;
    
    if (eeg_volt[i] < MAX_VOLT){
      for(j=start;j<end;j++){
	fprintf(FOUT_EMG,"%lf \n",data[j][EMG_CH]);
      }
    }
    else{
      k++;
      printf("Epoch %d is removed in file %d. \n",i, (i / EPOCH) + 1);
    }
  }
  
     
  fclose(FOUT_EMG);

  // system("rm *.ascii");  
  
    
  /*################Save Data(EEGs) in Output File for Z_Matrix################*/

  sprintf(fout,"%s-%d.mul",new_z,time);
  FOUT = fopen(fout,"w");

  fprintf(FOUT,"TimePoints= %d Channels= %d \n", ((FILESUU * EPOCH * INTERVAL) - (k * INTERVAL)), EEG_END - EEG_START +1);
  fprintf(FOUT," Fp1 F7 T3 T5 O1 F3 C3 P3 Fz Cz Pz F4 C4 P4 Fp2 F8 T4 T6 O2 \n");
  
  for(i=0;i<(FILESUU * EPOCH);i++){
    
    start = i * INTERVAL;
    end   = (i + 1) * INTERVAL;
    
    for(j=start;j<end;j++){

      if (eeg_volt[i] < MAX_VOLT){
	for(m=EEG_START;m<=EEG_END;m++){
	  fprintf(FOUT," %lf",data[j][m]);
	}
	fprintf(FOUT,"\n");
      }
    }
  }
  fclose(FOUT);
  
  printf("Total data is %d. \n",(FILESUU * EPOCH * INTERVAL) - (k * INTERVAL));
  
}
 
