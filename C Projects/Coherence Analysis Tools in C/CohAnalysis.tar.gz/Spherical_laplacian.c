/* ###################################################################
  
               Function that calculate scalp current density 
 
      Spherical_laplacian(char *g_fname,char *new_zfname, int time_band);

                 	    No return value

   ################################################################### */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include"CSD.h"   


Spherical_laplacian(char *g_fname,char *new_zfname, int time_band)
{
  int i, j, k, total_data, total_electrodes;
  int NUM, MAT;

  double **data;
  
  double **g; 

  double n;
  
  double *sum;

  char file_c[200], file_g[200];
 
  char file_out[200];

  char string[256], electrode[25][25], timepoints[20], elect[20];
 
  FILE *f_g, *f_c, *f_out;


  /*################Memory Allocation and Initalization################*/

  data = (double **)calloc(FILESUU*EPOCH*INTERVAL,sizeof(double *));
  if(data == NULL){
    puts("data �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
  }
  for(MAT=0;MAT<(FILESUU*EPOCH*INTERVAL);MAT++){
    *(data + MAT) = (double *)calloc(MATRIX+1,sizeof(double));
    if(*(data + MAT) == NULL){
    puts("data �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
    }
  }

  /*
  newdata = (double **)calloc(FILESUU*EPOCH*INTERVAL,sizeof(double *));
  if(newdata == NULL){
    puts("newdata �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
  }
  for(MAT=0;MAT<(FILESUU*EPOCH*INTERVAL);MAT++){
    *(newdata + MAT) = (double *)calloc(MATRIX+1,sizeof(double));
    if(*(newdata + MAT) == NULL){
    puts("newdata �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
    }
  }
  */

  g = (double **)calloc(MATRIX,sizeof(double *));
  if(g == NULL){
    puts("g �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
  }
  for(MAT=0;MAT<MATRIX;MAT++){
    *(g + MAT) = (double *)calloc(MATRIX,sizeof(double));
    if(*(g + MAT) == NULL){
    puts("g �Υ��꤬���ݤǤ��ޤ���");
    exit(1);
    }
  }

  sum = (double *)calloc(FILESUU*EPOCH*INTERVAL,sizeof(double));
  if(sum == NULL){
      puts("sum �Υ��꤬���ݤǤ��ޤ���");
      exit(1);
  }

  /*################Open for Read G(m-1) and Cn Input Files################*/

  sprintf(file_g,"%s",g_fname);

  f_g = fopen(file_g, "r");
  if (f_g == NULL){
    printf("Cannot open file %s. (Spherical_laplacian) \n",file_g);
    exit(-1);
  }
  
  sprintf(file_c,"%s-%d.csd",new_zfname,time_band);    
 
  f_c = fopen(file_c, "r");
  if (f_c == NULL){
    printf("Cannot open file %s. (Spherical_laplacian) \n",file_c);
    exit(-1);
  }
 

  /*################Read G(m-1) and Cn Input Files Data###############*/

  for(NUM=0;NUM<2;NUM++)
    fgets(string,256,f_g);

  for(i=0;i<MATRIX;i++){
    fscanf(f_g, "%s ", electrode[i]);
    for(j=0;j<MATRIX;j++){
      fscanf(f_g, "%lf ", &g[i][j]);
    }
  }
  fclose(f_g);
    
  fscanf(f_c,"%s %d %s %d \n",timepoints, &total_data, elect, &total_electrodes);
  fgets(string,256,f_c);
  
  for(i=0;i<total_data;i++){
    for(j=0;j<(MATRIX+1);j++){
      fscanf(f_c, "%lf ", &data[i][j-1]);
    }
  }
  fclose(f_c);

  
  /*################Calculate scalp current density(Perrin et. al. (1989))################*/

  for(k=0;k<total_data;k++){
    for(i=0;i<MATRIX;i++){
      sum[i] = 0.0;
      for(j=0;j<MATRIX;j++){
	n = g[i][j] * data[k][j];
	sum[i]+=n;
      }
      /*newdata[k][i] = sum;*/    
    }
    for(i=0;i<MATRIX;i++){
	data[k][i] = sum[i];
    }
  }
  
 /*################Create Output File################*/

  sprintf(file_out,"%s-%d.allcsd",new_zfname,time_band); 
  f_out = fopen(file_out, "w");
  if (f_out == NULL){
    printf("Cannot open file %s. (Spherical_laplacian) \n",file_out);
    exit(-1);
  }

  /*################Save Data in Output File################*/

  fprintf(f_out,"%s %d %s %d \n",timepoints, total_data, elect, total_electrodes);
  fprintf(f_out,"%s",string);
  for(i=0;i<total_data;i++){
    for(j=0;j<MATRIX;j++){
      fprintf(f_out, "%lf ", data[i][j]);
    }
    fprintf(f_out, "\n");
  }
  fclose(f_out);

  system("rm *.csd");
  system("rm *.mul");
}
