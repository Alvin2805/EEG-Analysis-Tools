#!/usr/local/bin/perl

if( $#ARGV == -1){
    printf "./gnu_wa.pl  <filename> <x_axis.start> <x_axis.end> <y_axis.start> <y_axis.end> <how.many.loop?> \n";
    exit;
    }


$FILE = $ARGV[0];
$XAXIS_START  = $ARGV[1];
$XAXIS_END  = $ARGV[2];
$YAXIS_START  = $ARGV[3];
$YAXIS_END = $ARGV[4];
$LOOP = $ARGV[5];
$end = $XAXIS_END - $XAXIS_START;

for($start = 0; $start < $LOOP; $start++)
{
    system "./gnu_wa ${FILE} ${XAXIS_START} ${XAXIS_END} ${YAXIS_START} ${YAXIS_END}";
    $XAXIS_START = $XAXIS_START + $end;
    $XAXIS_END = $XAXIS_END + $end;
}
